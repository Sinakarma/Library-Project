#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include<unistd.h>
#include <stdbool.h>
#include <string.h>
#include "library.c"

#define MaxTitle 27
#define MaxAuthor 20
#define MaxISBN 20
#define MaxCategory 20

typedef struct{
	char *title; // Title of the book
	char *author; // Author of the book
	char *ISBN; // International Standard Book Nummber (ISBN) of the book
	char *category; // Category of the book: history, science, literature...
	bool status; // The book is available or not
} book; 
int main()
{
	int choice = 0; char* Title; char* Author; char* ISBN; char* Category;
	{
	printf("\n\n\n\t\t\tEnter title: ");
        scanf("%s", Title);
        printf("\n\n\n\t\t\tEnter author: ");
        scanf("%s", Author);
        printf("\n\n\n\t\t\tEnter category: ");
        scanf("%s", Category);
        printf("\n\t\t\t2.");
        printf("\n\t\t\t3.Exit");
        printf("\n\n\n\t\t\tEnter choice => ");
        scanf("%d",&choice);
        switch(choice)
        {
        case 1:
            Login();
            break;
        case 2:
            AddUser();
            break;
        case 0:
            exit(1);
            break;
        default:
            printf("\n\n\n\t\t\tInvalid input!");
        }                                            
    }
    while(choice!=0);                                        
}
