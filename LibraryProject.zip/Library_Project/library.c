#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <stdbool.h>
#include <string.h>


FILE* USER ;

typedef struct
{
    char title[27];    // Title of the book
    char author[10];   // Author of the book
    char ISBN[13];     // International Standard Book Nummber (ISBN) of the book
    char category[11]; // Category of the book: history, science, literature...
    bool status;       // The book is available or not
} book;

void ViewApplicationTitle() // It is the title of the application to be printed before starting the application
{
    printf("\n\t\t\t        *********************************************");
    printf("\n\t\t\t        *                  CY-TECH                  *");
    printf("\n\t\t\t        *                  LIBRARY                  *");
    printf("\n\t\t\t        *                  APPLICATION              *");
    printf("\n\t\t\t        *********************************************\n");
}

void Login()
{
    printf("Le choix 1 a été fait\n") ;
    char login_entrer[20];
    char password_entrer[20];
    char login[20];
    char password[20];
    int good=0;
    
    
    printf("Quel est votre login ? \n");
    scanf("%s", login_entrer);
    printf("Quel est votre password ? \n");
    scanf("%s", password_entrer);
    USER=fopen("user.txt", "r"); // ouverture du fichier user en read
   
   
    /*if(strcmp(login_entrer,"abhi")==0 && strcmp(password_entrer,"Merco")==0)
    {
    	printf("Connexion approuvée ! Vous êtes connectés\n");
    }
    else
    {
    	printf("Problème d'authentification. Veuillez réessayer !\n");
    }
    fclose(USER);
    exit(0) ;*/

    if (USER)
		{
		
		while(fscanf(USER, "%s%s", login, password) != EOF && good == 0)
			{
			printf("le login est = %s\n", password) ;
            if(strcmp(login_entrer,login) == 0 && strcmp(password_entrer,password) == 0)
				{
				printf("The information entered was correct. \n");
				good = 1; 
				}
			
			
			}
		}
	if (good==0)
		printf("The username and password does not match. \n");

    fclose(USER) ;
    return ; 

}

void AddUser()
{
    printf("Création du compte en cours... \n") ;
    USER = fopen("user.txt", "a") ; //ouverture du fichier user
    char login_entrer[20] ;
    char password_entrer[20];
    char role_entrer[20] ;

    printf("Quel est votre login ? \n") ;
    scanf("%s" , login_entrer) ;           //récupération du login entré par l'utilisateur
    printf("Quel est votre password ? \n");
    scanf("%s", password_entrer) ;	     //récupération du password entré par l'utilisateur 
    printf("Etes vous un étudiant ou un professeur ?") ;
    scanf("%s", role_entrer) ;
    printf("Merci pour votre inscription ! Veuillez-vous connecter de nouveau ");

    fprintf(USER,"Login: %s\n", login_entrer) ; //ajouter le login et le password dans le  fichier
    fprintf(USER, "Mot de passe: %s\n\n", password_entrer) ; // ajouter le mot de passe dans le fichier
    fprintf(USER, "Role: %s\n\n", role_entrer) ; // ajouter le mot de passe dans le fichier
    fclose(USER) ;

    //exit(0) ;

    return ;

}

void Menu()
{
    int choice = 0;
    do
    {
        printf("\n\n\n\t\t\t1.Login");
        printf("\n\t\t\t2.New user");
        printf("\n\t\t\t3.Exit");
        printf("\n\n\n\t\t\tEnter choice => ");
        scanf("%d", &choice);
        switch (choice)
        {
        case 1:
            Login();
            break;
        case 2:
            AddUser();
            break;
        
        case 3:
            printf("A BIENTOT !\n") ;
            exit(1);
            break;
        default:
            printf("\n\n\n\t\t\tInvalid input!\n");
        }
    } while (choice != 0);
}

int main()
{

    ViewApplicationTitle() ;

    Menu() ;
    /*char StudentOrProfessor ; // si Student
    
    
    if (StudentOrProfessor == 0 )
    {
        int a = 0;

        while (a != 7)
        {
            system("cls");
            printf("Select an Option:\n");
            printf("1.Add Student Record\n");
            printf("2.Update Student Record\n");
            printf("3.Delete Student Record\n");
            printf("4.Mark Attendence\n");
            printf("5.Enter Marks\n");
            printf("6.Search\n");
            printf("7.Exit\n");
            printf("Enter:");

            scanf("%d", &a);

            switch (a)
            {
            case 1:
                addStudentRecord();
                break;

            case 2:
                updateStudentRecord();
                break;

            case 3:
                deleteStudentRecord();
                break;

            case 4:
                markAttendence();
                break;

            case 5:
                enterMarks();
                break;

            case 6:
                search();
                break;

            case 7:
                exit(0);
                break;

            default:
                printf("Invalid Option\n");
                break;
            }
        }
    }*/
}
/*void Newconnection()
{
    int choice = 0;
    do
    {
        headMessage("MAIN MENU");
        printf("\n\n\n\t\t\t1.Add Student");
        printf("\n\t\t\t2.Search Student");
        printf("\n\t\t\t3.View Student");
        printf("\n\t\t\t4.Delete Student");
        printf("\n\t\t\t5.Update Password");
        printf("\n\t\t\t0.Exit");
        printf("\n\n\n\t\t\tEnter choice => ");
        scanf("%d", &choice);
        switch (choice)
        {
        case 1:
            addStudentInDataBase();
            break;
        case 2:
            searchStudent();
            break;
        case 3:
            viewStudent();
            break;
        case 4:
            deleteStudent();
            break;
        case 5:
            updateCredential();
            break;
        case 0:
            printf("\n\n\n\t\t\t\tThank you!!!\n\n\n\n\n");
            exit(1);
            break;
        default:
            printf("\n\n\n\t\t\tINVALID INPUT!!! Try again...");
        }                  //Switch Ended
    } while (choice != 0); //Loop Ended
}*/

