#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

typedef struct{
	char *title; // Title of the book
	char *author; // Author of the book
	char *ISBN; // International Standard Book Nummber (ISBN) of the book
	char *category; // Category of the book: history, science, literature...
	bool status; // The book is available or not
} book; 

int main()
{
	char Title[27];
	char Author[20];
	char IISBN[20];
	char Category[20];
	int i;
	book *Book;
	book *TabBook=NULL;
	
	Title[27]="Pensées";
	Author[20]="B.Pascal";
	IISBN[20]="9788437616087";
	Category[20]="Littérature";
	Book->title=malloc(strlen(Title) );
	strcpy(Book->title,Title);
	printf("%s", Book->title);
	
	/*TabBook=malloc(2*sizeof(book));
	TabBook[0].title="Pensées'\0'";
    	TabBook[0].author="B.Pascal'\0'"; 
    	TabBook[0].ISBN="9788437616087'\0'";
    	TabBook[0].category="Littérature'\0'"; 
    	TabBook[0].status=false;
    	
    	
    	TabBook[1].title="Pensées'\0'"; 
    	TabBook[1].author="B.Pascal'\0'"; 
    	TabBook[1].ISBN="0788437616087'\0'"; 
    	TabBook[1].category="Littérature'\0'"; 
    	TabBook[1].status=false;
    	
    	
    	for(i=0; i<2; i++){
    		printf("%s" "%s" "%s" "%s", books[i].title, books[i].author, books[i].ISBN, books[i].category);
} */
return 0;
}    	
